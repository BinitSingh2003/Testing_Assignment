import fs from 'fs';
import path from 'path';

export function readCsv(fileName) {
  const filePath = path.resolve(process.cwd(), 'test-data', fileName);
  const content = fs.readFileSync(filePath, 'utf-8').trim();

  const [headerLine, ...dataLines] = content.split(/\r?\n/);
  const headers = headerLine.split(',').map(h => h.trim());

  return dataLines
    .filter(line => line.trim())
    .map(line => {
      const values = line.split(',').map(v => v.trim());
      return Object.fromEntries(headers.map((header, index) => [header, values[index] ?? '']));
    });
}
