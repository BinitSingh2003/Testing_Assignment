import { readCsv } from './csvReader.js';

export const testData = readCsv('testdata.csv');

export const validLoginData = testData.find(row => row.testCase === 'validLogin');
export const invalidLoginData = testData.find(row => row.testCase === 'invalidLogin');
export const blankLoginData = testData.find(row => row.testCase === 'blankLogin');
export const sameAccountTransferData = testData.find(
  row => row.testCase === 'sameAccountTransfer'
);
export const validTransferData = testData.find(
  row => row.testCase === 'validTransfer'
);
