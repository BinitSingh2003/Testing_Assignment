import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage.js';
import { BankPage } from '../pages/BankPage.js';
import {
  validLoginData,
  sameAccountTransferData,
  validTransferData
} from '../utils/testData.js';

test.describe('Altoro Mutual - Banking (CSV Data Driven)', () => {
  test.beforeEach(async ({ page }) => {
    const login = new LoginPage(page);

    await login.goto();
    await login.loginWithValidUser(
      validLoginData.username,
      validLoginData.password
    );
  });

  test('TC_BANK_001 - account summary is displayed', async ({ page }) => {
    const bank = new BankPage(page);

    await bank.openAccountSummary();

    await expect(page.locator('h1')).toContainText('Hello');
    await expect(bank.accountDropdown).toBeVisible();
    await expect(bank.accountDetailsButton).toBeVisible();
  });

  test('TC_BANK_002 - view savings account details', async ({ page }) => {
    const bank = new BankPage(page);

    await bank.viewAccountDetails(validLoginData.fromAccount);

    await expect(page.locator('body')).toContainText(validLoginData.fromAccount);
    await expect(page.locator('body')).toContainText(/Savings/i);
  });

  test('TC_BANK_003 - recent transactions page', async ({ page }) => {
    const bank = new BankPage(page);

    await bank.openTransactions();

    await expect(page.locator('body')).toContainText(/Account History|Transaction/i);
  });

  test('TC_BANK_004 - transfer page loads', async ({ page }) => {
    const bank = new BankPage(page);

    await bank.openTransfer();

    await expect(page.locator('h1')).toContainText(/Transfer Funds/i);
    await expect(bank.fromAccount).toBeVisible();
    await expect(bank.toAccount).toBeVisible();
    await expect(bank.transferAmount).toBeVisible();
  });

  test('TC_BANK_005 - same source and destination account is rejected', async ({ page }) => {
    const bank = new BankPage(page);

    await bank.openTransfer();

    const dialogPromise = page.waitForEvent('dialog');
    await bank.transferFunds(
      sameAccountTransferData.fromAccount,
      sameAccountTransferData.toAccount,
      sameAccountTransferData.amount
    );

    const dialog = await dialogPromise;

    expect(dialog.message()).toContain(
      'From Account and To Account fields cannot be the same.'
    );
    await dialog.dismiss();
  });

  test('TC_BANK_006 - valid fund transfer', async ({ page }) => {
    const bank = new BankPage(page);

    await bank.openTransfer();

    await bank.transferFunds(
      validTransferData.fromAccount,
      validTransferData.toAccount,
      validTransferData.amount
    );

    await expect(page.locator('body')).toContainText(/successfully transferred/i);
  });

  test('TC_BANK_007 - logout', async ({ page }) => {
    const bank = new BankPage(page);

    await bank.logout();

    await expect(page).toHaveURL(/\/login\.jsp/);
    await expect(page.locator('#uid')).toBeVisible();
  });
});
