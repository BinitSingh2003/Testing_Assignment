import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage.js';
import {
  validLoginData,
  invalidLoginData,
  blankLoginData
} from '../utils/testData.js';

test.describe('Altoro Mutual - Login (CSV Data Driven)', () => {
  test('TC_LOGIN_001 - valid login', async ({ page }) => {
    const login = new LoginPage(page);

    await login.goto();
    await login.loginWithValidUser(
      validLoginData.username,
      validLoginData.password
    );

    await expect(page.locator('h1')).toContainText('Hello');
    await expect(page).toHaveURL(/\/bank\/main\.jsp/);
  });

  test('TC_LOGIN_002 - invalid login', async ({ page }) => {
    const login = new LoginPage(page);

    await login.goto();
    await login.login(
      invalidLoginData.username,
      invalidLoginData.password
    );

    await expect(page).toHaveURL(/\/login\.jsp/);
    await expect(page.locator('body')).toContainText(/Login Failed|username|password/i);
  });

  test('TC_LOGIN_003 - blank username and password', async ({ page }) => {
    const login = new LoginPage(page);

    await login.goto();
    await login.login(
      blankLoginData.username,
      blankLoginData.password
    );

    await expect(page).toHaveURL(/\/login\.jsp/);
  });
});
