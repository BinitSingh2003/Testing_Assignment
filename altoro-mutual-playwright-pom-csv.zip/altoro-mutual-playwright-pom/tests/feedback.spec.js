import { test, expect } from '@playwright/test';
import { FeedbackPage } from '../pages/FeedbackPage.js';

test.describe('Altoro Mutual - Feedback', () => {
  test('TC_FEEDBACK_001 - feedback page loads', async ({ page }) => {
    const feedback = new FeedbackPage(page);

    await feedback.goto();

    await expect(page.locator('h1')).toContainText('Feedback');
    await expect(feedback.comment).toBeVisible();
  });

  test('TC_FEEDBACK_002 - submit feedback with valid data', async ({ page }) => {
    const feedback = new FeedbackPage(page);

    await feedback.goto();
    await feedback.submitFeedback(
      'Automation Tester',
      'tester@example.com',
      'Automation Test',
      'This is an automated feedback test.'
    );

    await expect(page.locator('body')).toContainText(/thank|feedback|submitted|success/i);
  });
});
