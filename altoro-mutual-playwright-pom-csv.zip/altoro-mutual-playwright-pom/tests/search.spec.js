import { test, expect } from '@playwright/test';
import { SearchPage } from '../pages/SearchPage.js';

test.describe('Altoro Mutual - Search', () => {
  test('TC_SEARCH_001 - search for a valid keyword', async ({ page }) => {
    const search = new SearchPage(page);

    await page.goto('/index.jsp');
    await search.search('bank');

    await expect(page.locator('body')).toContainText(/search/i);
  });

  test('TC_SEARCH_002 - search with no keyword', async ({ page }) => {
    const search = new SearchPage(page);

    await page.goto('/index.jsp');
    await search.search('');

    await expect(page).toHaveURL(/search\.jsp|index\.jsp/);
  });
});
