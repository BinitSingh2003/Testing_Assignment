export class BankPage {
  constructor(page) {
    this.page = page;

    this.accountSummaryLink = page.locator('#MenuHyperLink1');
    this.transactionsLink = page.locator('#MenuHyperLink2');
    this.transferLink = page.locator('#MenuHyperLink3');
    this.searchNewsLink = page.locator('#MenuHyperLink4');
    this.signOffLink = page.locator('#LoginLink');

    this.accountDropdown = page.locator('#listAccounts');
    this.accountDetailsButton = page.locator('#btnGetAccount');

    this.fromAccount = page.locator('#fromAccount');
    this.toAccount = page.locator('#toAccount');
    this.transferAmount = page.locator('#transferAmount');
    this.transferButton = page.locator('input[name="transfer"][value="Transfer Money"]');

    this.searchBox = page.locator('#query');
    this.searchButton = page.locator('input[type="submit"][value="Go"]');
  }

  async openAccountSummary() {
    await this.accountSummaryLink.click();
    await this.page.waitForURL('**/bank/main.jsp');
  }

  async openTransactions() {
    await this.transactionsLink.click();
    await this.page.waitForURL('**/bank/transaction.jsp');
  }

  async openTransfer() {
    await this.transferLink.click();
    await this.page.waitForURL('**/bank/transfer.jsp');
  }

  async selectAccount(account) {
    await this.accountDropdown.selectOption(account);
  }

  async viewAccountDetails(account) {
    await this.selectAccount(account);
    await this.accountDetailsButton.click();
    await this.page.waitForURL('**/bank/showAccount**');
  }

  async transferFunds(fromAccount, toAccount, amount) {
    await this.fromAccount.selectOption(fromAccount);
    await this.toAccount.selectOption(toAccount);
    await this.transferAmount.fill(String(amount));
    await this.transferButton.click();
  }

  async searchNews(keyword) {
    await this.searchBox.fill(keyword);
    await this.searchButton.click();
  }

  async logout() {
    await this.signOffLink.click();
    await this.page.waitForURL('**/login.jsp');
  }
}
