export class LoginPage {
  constructor(page) {
    this.page = page;
    this.username = page.locator('#uid');
    this.password = page.locator('#passw');
    this.loginButton = page.locator('input[name="btnSubmit"][value="Login"]');
  }

  async goto() {
    await this.page.goto('/login.jsp');
  }

  async login(username, password) {
    await this.username.fill(username);
    await this.password.fill(password);
    await this.loginButton.click();
  }

  async loginWithValidUser(username, password) {
    await this.login(username, password);
    await this.page.waitForURL('**/bank/main.jsp');
  }

  async getLoginError() {
    return this.page.locator('body').innerText();
  }
}
