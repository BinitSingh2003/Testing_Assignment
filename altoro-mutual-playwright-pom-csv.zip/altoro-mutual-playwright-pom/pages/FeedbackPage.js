export class FeedbackPage {
  constructor(page) {
    this.page = page;

    // The current Altoro Mutual feedback page uses labels without stable IDs,
    // so these locators intentionally use the form structure/field types.
    this.name = page.locator('input').nth(1);
    this.email = page.locator('input').nth(2);
    this.subject = page.locator('input').nth(3);
    this.comment = page.locator('textarea');
    this.submit = page.locator('input[type="submit"]').first();
    this.clear = page.locator('input[type="reset"]');
  }

  async goto() {
    await this.page.goto('/feedback.jsp');
  }

  async submitFeedback(name, email, subject, comment) {
    await this.name.fill(name);
    await this.email.fill(email);
    await this.subject.fill(subject);
    await this.comment.fill(comment);
    await this.submit.click();
  }
}
