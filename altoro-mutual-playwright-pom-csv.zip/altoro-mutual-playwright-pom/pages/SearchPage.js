export class SearchPage {
  constructor(page) {
    this.page = page;
    this.searchBox = page.locator('#query');
    this.searchButton = page.locator('input[type="submit"][value="Go"]');
  }

  async search(keyword) {
    await this.searchBox.fill(keyword);
    await this.searchButton.click();
  }

  async getBodyText() {
    return this.page.locator('body').innerText();
  }
}
