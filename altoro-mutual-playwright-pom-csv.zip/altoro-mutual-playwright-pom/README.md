# Altoro Mutual - Playwright JavaScript POM Automation

A maintainable UI automation framework using **Playwright + JavaScript + Page Object Model**.

## Application

Base URL: `https://www.testfire.net`

Altoro Mutual is a demo banking application. The current site exposes an online banking login and banking navigation including account summary, recent transactions, fund transfer, search news articles, and logout.

## Framework structure

```text
altoro-mutual-playwright-pom/
│
├── pages/
│   ├── LoginPage.js
│   ├── BankPage.js
│   ├── FeedbackPage.js
│   └── SearchPage.js
│
├── tests/
│   ├── login.spec.js
│   ├── banking.spec.js
│   ├── feedback.spec.js
│   └── search.spec.js
│
├── utils/
│   └── testData.js
│
├── playwright.config.js
├── package.json
├── .env.example
└── README.md
```

## Install

```bash
npm install
npx playwright install
```

## Run all tests

```bash
npm test
```

## Run headed

```bash
npm run test:headed
```

## Debug

```bash
npm run test:debug
```

## HTML report

```bash
npm run report
```

## Test coverage

### Login
- Valid login
- Invalid username/password
- Blank credentials / client-side validation

### Banking
- Account summary
- Savings account details
- Recent transactions
- Transfer page
- Same source/destination negative case
- Valid fund transfer
- Logout

### Feedback
- Feedback page
- Valid feedback submission

### Search
- Valid keyword
- Empty search

## POM design

The tests contain business-level steps only. Locators and page interactions stay inside page classes.

Example:

```js
const login = new LoginPage(page);
await login.loginWithValidUser(username, password);
```

instead of putting selectors directly in the test.

## Credentials

The project defaults to the commonly documented demo credentials:

```text
Username: jsmith
Password: demo1234
```

For a team/CI environment, prefer environment variables:

```text
ALTORO_USERNAME=jsmith
ALTORO_PASSWORD=demo1234
```

## Important note about the transfer test

`TC_BANK_006` performs a real state-changing transfer in the demo application. It transfers only `1` unit from the savings account to the checking account. Because the demo environment can retain state, you may want to tag/skip this test in CI and keep it for controlled local execution.

## Locator strategy

The framework uses stable attributes where available, such as:
- `#uid`
- `#passw`
- `#MenuHyperLink1` ... `#MenuHyperLink5`
- `#listAccounts`
- `#btnGetAccount`
- `#fromAccount`
- `#toAccount`
- `#transferAmount`
- `#LoginLink`

Where the application does not expose stable IDs, the page object uses form structure and semantic text.

## Next improvements

For a stronger interview-level project, add:
1. Fixtures for login/session reuse
2. `storageState` authentication
3. Data-driven testing
4. API tests for the Altoro REST API
5. CI/CD with GitHub Actions
6. Allure/HTML reporting
7. Screenshot and trace attachment
8. Environment configuration for QA/Stage
9. Retry strategy for known transient failures
10. Tagging: `@smoke`, `@regression`, `@negative`


## CSV-driven test data

Test data is stored in:

```text
test-data/testdata.csv
```

The CSV contains columns for:
- username
- password
- fromAccount
- toAccount
- amount
- expected

The test classes load the CSV through:

```text
utils/csvReader.js
```

This keeps test data outside the test scripts and allows you to add/change
test scenarios without changing the Page Objects.

Example:

```csv
testCase,username,password,fromAccount,toAccount,amount,expected
validLogin,jsmith,demo1234,800002,800003,1,success
invalidLogin,invalid_user,invalid_password,800002,800003,1,failure
sameAccountTransfer,jsmith,demo1234,800002,800002,1,failure
```

To add another data set, add a row to the CSV and reference it by `testCase`
in the test.
